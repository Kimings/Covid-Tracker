package com.example.covidTracker;

public class Covid {
    private String casses;
    private String deaths;
    private String recovered;


    public String getCasses() {
        return casses;
    }

    public void setCasses(String casses) {
        this.casses = casses;
    }

    public String getDeaths() {
        return deaths;
    }

    public void setDeaths(String deaths) {
        this.deaths = deaths;
    }

    public String getRecovered() {
        return recovered;
    }

    public void setRecovered(String recovered) {
        this.recovered = recovered;
    }
}
